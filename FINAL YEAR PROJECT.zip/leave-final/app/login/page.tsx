import AuthComponent from '@/components/Other/AuthComponent'


const LoginPage = () => {
  return (
    <AuthComponent/>
  )
}

export default LoginPage