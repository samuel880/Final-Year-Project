import AuthComponent from "@/components/Other/AuthComponent";


export default function Home() {
  return (
    <AuthComponent/>
  )
}
